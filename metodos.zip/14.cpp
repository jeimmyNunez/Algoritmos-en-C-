#include<iostream>
 using namespace std;

int mcm(){
    int numero1, numero2, producto;
    int residuo, mcd, mcm;

    cout << "numero 1:" << endl;
    cin>> numero1;

    cout <<" numero 2:" << endl;
    cin>> numero2;

producto = numero1 * numero2;
    do {
        residuo=numero1 % numero2;

        if(residuo !=0){
            numero1 = numero2;
            numero2=residuo;
        } else {
            mcd=numero2;
        }
    }while (residuo !=0);

    mcm= producto / mcd;
    cout <<"el mcm es" << mcm <<endl;
}


 int main () {
 
int  a, b;

 cout <<" ingrese el primer numero:" << endl;
 cin>> a;

cout <<" ingrese el segundo numero:" << endl;
 cin>> b;

bool MCD = false;

    int aux = a;
    a = b;
    b= aux;

    int i = a;

    while(!MCD &&  i>= 1){

        if (a % i == 0 && b % i== 0){
            cout << "El MCD es " << i << endl;
            MCD =  true;
        }
        else {
            i--;
        }
    }
mcm();

    return 0;
 }