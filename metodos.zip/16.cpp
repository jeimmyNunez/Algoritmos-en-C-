#include <iostream>
using namespace std;

int funcionseno(){
sen = ladopuesto % hipotenusa;

}

int funcioncoseno(){
    cos = ladoadyacente % h;
    
}

int funciontangente(){
    tan = ladopuesto % ladoadyacente;
    
}

int main() {

int seno;
 int ladopuesto;
 int ladoadyacente;
 int hipotenusa;

    cout << "Ingrese el lado opuesto " << endl;
    cin >> ladopuesto;

 cout << "Ingrese el lado adyacente " << endl;
    cin >> ladoadyacente;

     cout << "Ingrese la hipotenusa " << endl;
    cin >> hipotenusa;

cout << "El seno,segun los angulos dados anteriormente es:" << sen << endl;
cout << "El coseno,segun los angulos dados anteriormente es:" << cos << endl;
cout << "La tangente,segun los angulos dados anteriormente es:" << tan << endl;

retun 0;

}