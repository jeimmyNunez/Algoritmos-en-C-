#include <iostream>
#include <string>
#include <cmath>
    using namespace std;
    void calcularMedia();
    void calcularVarianza();
    void calcularDesviacion();

    
   
    // Declarar variables globales o de clase
       float numeros[20];
       int n, opcion ;
       double sumatoria, media, varianza, desviacion, desviacionEstandar;
       string datoEntrada;

       
       int main(){
       	
       	
        // Crear objeto para entrada de datos por el teclado
           int opcion;
           cout << "---------------------------" << endl;
           cout << "|  MEDIDAS ESTADISTICAS   |" << endl;
           cout << "|-------------------------|" << endl;
           cout << "|  1. MEDIA               |" << endl;
           cout << "|  2. VARIANZA            |" << endl;
           cout << "|  3. DESVIACION ESTANDAR |" << endl;
           cout << "|  4. TODAS               |" << endl;
           cout << "|  5. FIN                 |" << endl;
           cout << "|-------------------------|" << endl;
           cout << "   TECLEE OPCION: ";
           cin >> opcion;         

           for (n = 0; n <= 19; n++){
               cout << "Teclee numeros[" << n << "]: ";
               cin >> numeros[n];
           }

           cout << "\n-------- Numeros --------" << endl;
           for (n = 0; n <= 3; n++){
               cout << "Numeros[" << n << "] = " << numeros[n] << endl;
           }

           if (opcion == 1 || opcion == 4){
              calcularMedia();
              cout << "Media = " << media << endl;
           }
           if (opcion == 2 || opcion == 4){
              calcularVarianza();
              std::cout << "Varianza = " << varianza << std::endl;
           }

            if (opcion == 3 || opcion == 4){
              calcularDesviacion();
              std::cout << "Desviacion estandar = " << desviacion << std::endl;
            }
            return 0;
      }

      void calcularMedia(){
       sumatoria = 0;
         for (int n = 0; n <= 19; n++){
         	
          sumatoria = sumatoria + numeros[n];
         }
        media = sumatoria / 20.0;
      }

        void calcularVarianza(){
         calcularMedia();
         sumatoria = 0;
          for (int n = 0; n <= 19; n++){
             desviacion = numeros[n] - media;
            if (desviacion > 0){
             desviacion = pow(desviacion,2);
             sumatoria = sumatoria + desviacion;
             }
          }
          varianza = sumatoria / 19.0;
        }

      void calcularDesviacion(){
        calcularVarianza();
        desviacionEstandar = sqrt(varianza);
}


