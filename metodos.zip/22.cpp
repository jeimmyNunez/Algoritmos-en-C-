#include <iostream>
#include <string>
#include <vector>

bool esOperador(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

void leerExpresion(std::string& expresion, std::vector<char>& operandos, std::vector<char>& operadores) {
    std::cout << "Ingrese una expresion aritmetica: ";
    std::getline(std::cin, expresion);

    for (size_t i = 0; i < expresion.length(); i++) {
        char c = expresion[i];
        if (c == '(' || c == ')') {
            continue;  
        } else if (esOperador(c)) {
            operadores.push_back(c);
        } else {
            operandos.push_back(c);
        }
    }
}

void imprimirExpresion(const std::string& expresion, const std::vector<char>& operandos, const std::vector<char>& operadores) {
    std::cout << "Expresion: " << expresion << std::endl;

    std::cout << "Operandos: ";
    for (size_t i = 0; i < operandos.size(); i++) {
        std::cout << operandos[i] << " ";
    }
    std::cout << std::endl;

    std::cout << "Operadores: ";
    for (size_t i = 0; i < operadores.size(); i++) {
        std::cout << operadores[i] << " ";
    }
    std::cout << std::endl;
}

int main() {
    std::string expresion;
    std::vector<char> operandos;
    std::vector<char> operadores;

    leerExpresion(expresion, operandos, operadores);
    std::cout << std::endl;

    imprimirExpresion(expresion, operandos, operadores);

    return 0;
}

