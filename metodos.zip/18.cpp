#include<iostream>
#include<stdlib.h>
using namespace std;

class resultado{
	private:
		int dividendo,divisor;

	public:
		resultado(int,int);
		void cociente();
		void residuo();
};
resultado::resultado( int _dividendo, int _divisor){
	dividendo= _dividendo;
	divisor= _divisor;
}

void resultado::cociente(){
	int _cociente;
	_cociente =dividendo/divisor;
	cout<<"el cociente de la division "<<dividendo<<"/"<<divisor<<" = "<<_cociente<<endl;
}
void resultado::residuo(){
	int _residuo;
	_residuo = dividendo%divisor;
	cout<<"el residuo de la division "<<dividendo<<"/"<<divisor<<" = "<<_residuo<<endl;
}

int main(){
	int a,b;
	cout<<"Ingresa el valor del dividendo : ";
	cin >>a;
	cout<<"Ingresa el valor del divisor : ";
	cin >>b;
	
	resultado r1(a,b);
	
	r1.cociente();
	r1.residuo();
	
	return 0;
}	
