#include <iostream>
 using namespace std;

 int main(){

    int dat1, dat2, dat3, dat4, dat5, dat6, dat7, dat8, dat9, dat10, dat11,dat12,dat13,dat14,dat15,dat16,dat17,dat18,dat19,dat20;
    int va1, va2, va3, va4, va5, va6, va7, va8, va9, va10, va11, va12, va13, va14, va15, va16, va17, va18, va19, va20;


        va1=dat1 % 2;
        va2= dat2 % 2;
        va3= dat3 % 2;
        va4= dat4 % 2;
        va5= dat5 % 2;
        va6= dat6 % 2;
        va7= dat7 % 2;
        va8= dat8 % 2;
        va9= dat9 % 2;
        va10= dat10 % 2;
        va11= dat11 % 2;
        va12= dat12 % 2;
        va13= dat13 % 2;
        va14= dat14 % 2;
        va15= dat15 % 2;
        va16= dat16 % 2;
        va17= dat17 % 2;
        va18= dat18 % 2;
        va19= dat1 % 2;
        va20= dat1 % 2;

    cout << "Digite el numero 1:" << va1 << endl;
        cin >>dat1;
        
            if(va1==0){
                cout << "par" << endl;
            }
            else {
                cout <<"impar" << endl;
            }
            

    cout << "Digite el numero 2:" << va2 << endl;
        cin >>dat2;

                if(va2==0){
                cout << "par"; << endl;
                 }
                else {
                cout <<"impar"; << endl;
                 }

    cout << "Digite el numero 3:" << va3 << endl;
        cin >>dat3;
                    if(va3==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }

    cout << "Digite el numero 4:" << va4 << endl;
        cin >>dat4;
       
                        if(va4==0){
                        cout << "par"; << endl;
                        }
                        else {
                        cout <<"impar"; << endl;
                        }    
    cout << "Digite el numero 5:" << va5 << endl;
        cin >>dat5;
        
            if(va5==0){
            cout << "par"; << endl;
            }
            else {
            cout <<"impar"; << endl;
            }

    cout << "Digite el numero 6:" << va6 << endl;
        cin >>dat6;
        
                if(va6==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }
    cout << "Digite el numero 7:" << va7 << endl;
        cin >>dat7;
        
                    if(va7==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }

    cout << "Digite el numero 8:" << va8 << endl;
        cin >>dat8;
        
                        if(va8==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }
    cout << "Digite el numero 9:" << va9 << endl;
        cin >>dat9;
       
                            if(va9==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }

    cout << "Digite el numero 10:" << va10 << endl;
        cin >>dat10;
        
            if(va10==0){
            cout << "par"; << endl;
            }
            else {
            cout <<"impar"; << endl;
            }

    cout << "Digite el numero 11:" << va11 << endl;
        cin >>dat11;
       
                if(va11==0){
                cout << "par"; << endl;
                }
                else {
                cout <<"impar"; << endl;
                }

    cout << "Digite el numero 12:" << va12 << endl;
        cin >>dat12;
        
                    if(va12==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }

   cout << "Digite el numero 13:" << va13 << endl;
        cin >>dat13;
        
                        if(va13==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }
    cout << "Digite el numero 14:" << va14 << endl;
        cin >>dat14;
        
        if(va14==0){
        cout << "par"; << endl;
        }
        else { 
        cout <<"impar"; << endl;
        }
    cout << "Digite el numero 15:" << va15 << endl;
        cin >>dat15;
       ;
            if(va15==0){
            cout << "par"; << endl;
            }
            else {
            cout <<"impar"; << endl;
            }

    cout << "Digite el numero 16:" << va16 << endl;
        cin >>dat16;

                if(va16==0){
        cout << "par"; << endl;
        }
        else {
        cout <<"impar"; << endl;
        }
    cout << "Digite el numero 17:" << va17 << endl;
        cin >>dat17;
        
        if(va17==0){
        cout << "par"; << endl;
        }
        else {
        cout <<"impar"; << endl;
        }
    cout << "Digite el numero 18:" << va18 << endl;
        cin >>dat18;
      
                    if(va18==0){
                    cout << "par"; << endl;
                    }
                    else {
                    cout <<"impar"; << endl;
                    }
    cout << "Digite el numero 19:" << va19 << endl;
        cin >>dat19;
       
        if(va19==0){
        cout << "par"; << endl;
        }
        else {
        cout <<"impar"; << endl;
        }

    cout << "Digite el numero 20:" << va20 << endl;
        cin >>dat20;
        
                if(va20==0){
                cout << "par"; << endl;
                }
                else {
                cout <<"impar"; << endl;
                }

        return 0;

    }

 