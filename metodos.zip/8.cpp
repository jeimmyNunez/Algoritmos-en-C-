#include <iostream>
using namespace std;

string tipo_triangulo(float a, float b, float c) {
    if (c*c == a*a + b*b) {
        return "rectangulo";
    }
    else if (c*c < a*a + b*b) {
        return "acutangulo";
    }
    else {
        return "obtusangulo";
    }
}

int main() {
    float a, b, c;
    cout << "Ingrese los valores de los catetos y la hipotenusa: ";
    cin >> a >> b >> c;
    string tipo = tipo_triangulo(a, b, c);
    cout << "El triangulo es " << tipo << "." << endl;
    return 0;
}
