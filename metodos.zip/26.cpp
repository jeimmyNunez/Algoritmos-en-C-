#include <iostream>
#include <string>
#include <vector>
using namespace std;

vector<string> palabras_mas_largas(string frase) {
    vector<string> palabras;
    string palabra_actual = "";
    int longitud_actual = 0;
    int longitud_maxima = 0;

    for (char c : frase) {
        if (c == ' ') {
            if (longitud_actual > longitud_maxima) {
                palabras.clear();
                palabras.push_back(palabra_actual);
                longitud_maxima = longitud_actual;
            }
            else if (longitud_actual == longitud_maxima) {
                palabras.push_back(palabra_actual);
            }
            palabra_actual = "";
            longitud_actual = 0;
        }
        else {
            palabra_actual += c;
            longitud_actual++;
        }
    }

    if (longitud_actual > longitud_maxima) {
        palabras.clear();
        palabras.push_back(palabra_actual);
    }
    else if (longitud_actual == longitud_maxima) {
        palabras.push_back(palabra_actual);
    }

    return palabras;
}

int main() {
    string frase;
    cout << "Ingrese una frase u oracion: ";
    getline(cin, frase);
    vector<string> palabras = palabras_mas_largas(frase);
    if (palabras.size() == 1) {
        cout << "La palabra mas larga es: " << palabras[0] << endl;
    }
    else {
        cout << "Las palabras mas largas son: ";
        for (int i = 0; i < palabras.size(); i++) {
            if (i == palabras.size() - 1) {
                cout << palabras[i] << "." << endl;
            }
            else {
                cout << palabras[i] << ", ";
            }
        }
    }
    return 0;
}
