#include <iostream>
using namespace std;

void calcular_billetes_monedas(float cantidad) {
    int denominaciones[] = {500, 200, 100, 50, 20, 10, 5, 2, 1, 50, 20, 10, 5};
    string nombres[] = {"billetes de 500", "billetes de 200", "billetes de 100", "billetes de 50", 
                        "billetes de 20", "billetes de 10", "billetes de 5", "monedas de 2", 
                        "monedas de 1", "monedas de 50 centavos", "monedas de 20 centavos", 
                        "monedas de 10 centavos", "monedas de 5 centavos"};
    int cantidades[13] = {0};
    int i = 0;
    while (cantidad > 0 && i < 13) {
        int cantidad_denominacion = cantidad / denominaciones[i];
        if (cantidad_denominacion > 0) {
            cantidades[i] = cantidad_denominacion;
            cantidad -= cantidad_denominacion * denominaciones[i];
        }
        i++;
    }
    cout << "Para cubrir la cantidad de $" << cantidad << " se necesitan:\n";
    for (int i = 0; i < 13; i++) {
        if (cantidades[i] > 0) {
            cout << cantidades[i] << " " << nombres[i] << endl;
        }
    }
}

int main() {
    float cantidad;
    cout << "Ingrese la cantidad a calcular: ";
    cin >> cantidad;
    calcular_billetes_monedas(cantidad);
    return 0;
}
