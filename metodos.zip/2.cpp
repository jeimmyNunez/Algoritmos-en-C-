#include <iostream>
#include <iomanip>
using namespace std;

void menu();
void convertirMetros(float);

int main()
{
    menu();

    return 0;
}

void menu()
{
    int opcion;
    
    cout << "-----------------------" << endl;
    cout <<     "MENU OPCIONES\t" << endl;
    cout << "-----------------------" << endl;
    cout << "1. Convertir Metros" << endl;
    cout << "-----------------------" << endl;
    cout << "2. Convertir Yardas" << endl;
    cout << "-----------------------" << endl;
    cout << "3. Convertir Pulgadas" << endl;
    cout << "-----------------------" << endl;
    cout << "4. Convertir Pies" << endl;
    cout << "-----------------------" << endl;
    cout << "5. Salir" << endl;
    cout << "-----------------------" << endl;


    cout << "Seleccione una opcion: " << endl;
    cin >> opcion;

    switch (opcion)
    {
    case 1:
        float metros;
        cout << "Ingrese la cantidad de metros a convertir: ";
        cin >> metros;
        convertirMetros(metros);
        break;
    case 2:
        break;
    case 3:
        break;
    case 4:
        break;
    case 5:
        cout << "Gracias por utilizar el programa" << endl;
        break;
    default:
        cout << "La opci�n seleccionada no es valida" << endl;
        break;
    }
}

void convertirMetros(float metros)
{
    float yardas, pulgadas, pies;

    yardas = metros * 1.09;
    pulgadas = metros * 39.37;
    pies = metros * 3.28;
    
    cout << "--------------------------------------------------------" << endl;
    cout << setw(10) << "METROS" << setw(10) << "YARDAS" << setw(10) << "PULGADAS" << setw(10) << "PIES" << endl;
    cout << "--------------------------------------------------------" << endl;
    for (float i = 1.0; i <= metros; i++)
    {
        cout << setw(10) << i << setw(10) << i * yardas << setw(10) << i * pulgadas << setw(10) << i * pies << endl;
    }
}
