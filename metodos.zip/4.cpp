#include <iostream>
#include <iomanip>

using namespace std;

void printTable(int op, int num) {
    switch (op) {
        case 1:
        	 cout << "--------------------------" << endl;
            cout <<    "Tabla de  multiplicar a " << num << endl;
             cout << "--------------------------" << endl;
            for (int i = 1; i <= 10; i++) {
                cout << setw(2) << i << " x " << setw(2) << num << " = " << setw(2) << i * num << endl;
            }
            break;
        case 2:
        	 cout << "-----------------------" << endl;
            cout <<      "Tabla de dividir a  " << num << endl;
             cout << "-----------------------" << endl;
            for (int i = 1; i <= 10; i++) {
                cout << setw(2) << i * num << " / " << setw(2) << num << " = " << setw(2) << i << endl;
            }
            break;
        case 3:
        	 cout << "-----------------------" << endl;
            cout <<      "Tabla de sumar a " << num << endl;
             cout << "-----------------------" << endl;
            for (int i = 1; i <= 10; i++) {
                cout << setw(2) << i << " + " << setw(2) << num<< " = " << setw(2) << i + num<< endl;
            }
            break;
        case 4:
        	 cout << "-----------------------" << endl;
            cout <<      "Tabla de restar a " << num << endl;
             cout << "-----------------------" << endl;
            for (int i = 1; i <= 10; i++) {
                cout << setw(2) << i * num << " - " << setw(2) << num << " = " << setw(2) << i - 1 << endl;
            }
            break;
        default:
            cout << "Operacion invalida" << endl;
            break;
    }
}

int main() {
    int op, num;
     cout << "-----------------------" << endl;
    cout << "Seleccione una operacion:" << endl;
     cout << "-----------------------" << endl;
    cout << "1. Multiplicacion" << endl;
     cout << "-----------------------" << endl;
    cout << "2. Division" << endl;
     cout << "-----------------------" << endl;
    cout << "3. Suma" << endl;
     cout << "-----------------------" << endl;
    cout << "4. Resta" << endl;
     cout << "-----------------------" << endl;
    cin >> op;
    cout << "Seleccione un numero:" << endl;
    cin >> num;
    printTable(op, num);
    return 0;
}
