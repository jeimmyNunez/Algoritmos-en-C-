#include <iostream>
#include <cmath>

using namespace std;

class Triangulo {
    private:
        double a, b, c;
    public:
        void lados(double A, double B, double C) {
            a = A;
            b = B;
            c = C;
        }
        double calcHip() {
            return sqrt(a * a + b * b);
        }
        double calcA() {
            return sqrt(c * c - b * b);
        }
        double calcB() {
            return sqrt(c * c - a * a);
        }
};

int main() {
    int escoger;
    double a, b, c;
    Triangulo triangulo;
    
    cout << "-----------------------"<< endl;
    cout << "Seleccione una opcion:" << endl;
    cout << "-----------------------"<< endl;
    cout << "1. Calcular hipotenusa" << endl;
    cout << "-----------------------"<< endl;
    cout << "2. Calcular cateto A" << endl;
    cout << "-----------------------"<< endl;
    cout << "3. Calcular cateto B" << endl;
    cout << "-----------------------"<< endl;
    cin >> escoger;
    switch (escoger) {
        case 1:
            cout << "Ingrese cateto A:" << endl;
            cin >> a;
            cout << "Ingrese cateto B:" << endl;
            cin >> b;
            triangulo.lados(a, b, 0);
            cout << "Hipotenusa = " << triangulo.calcHip() << endl;
            break;
        case 2:
            cout << "Ingrese hipotenusa:" << endl;
            cin >> c;
            cout << "Ingrese cateto B:" << endl;
            cin >> b;
            triangulo.lados(0, b, c);
            cout << "A = " << triangulo.calcA() << endl;
            break;
        case 3:
            cout << "Ingrese hipotenusa:" << endl;
            cin >> c;
            cout << "Ingrese cateto A:" << endl;
            cin >> a;
            triangulo.lados(a, 0, c);
            cout << "B = " << triangulo.calcB() << endl;
            break;
        default:
            cout << "La opcion selecciona es invalida" << endl;
            break;
    }
    return 0;
}
