#include<iostream>
#include<conio.h>
#include<string>

using namespace std;

void llenar_matriz();
void mayor();

int matriz[4][5];

int main(){
	llenar_matriz();
	mayor();
}

void llenar_matriz(){
	int r, c, renMay=0, colMay=0, mayor;
	cout << "-----------------------------LECTURA DE DATOS--------------------- "  << endl;
	for (r = 0; r <= 4; r++){
		for (c = 0; c <= 5; c++){
		    cout << "Teclee matriz[" << r << "," << c << "]: ";
            cin >> matriz[r][c];	
		}
	}
	
	
}

void mayor(){
	int r, c, mayor;
	cout << "-----------------------------MAYOR--------------------- "  << endl;
	    mayor=matriz[0][0];
		for (r = 0; r <= 4; r++){
		for (c = 0; c <= 5; c++){
			
			if(mayor<matriz[r][c]){
				mayor=matriz[r][c];
			}
				
		}
	}
	cout<<"\nel numero mayor es de: "<<mayor<<endl;
}
