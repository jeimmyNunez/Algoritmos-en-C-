#include <iostream>

const int FILAS = 5;
const int COLUMNAS = 7;

void leerArreglo(int arreglo[FILAS][COLUMNAS]) {
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            std::cout << "Ingrese el valor para el elemento [" << i << "][" << j << "]: ";
            std::cin >> arreglo[i][j];
        }
    }
}

void calcularSumatorias(int arreglo[FILAS][COLUMNAS], int sumatoriasFilas[FILAS], int sumatoriasColumnas[COLUMNAS]) {
    for (int i = 0; i < FILAS; i++) {
        sumatoriasFilas[i] = 0;
        for (int j = 0; j < COLUMNAS; j++) {
            sumatoriasFilas[i] += arreglo[i][j];
            sumatoriasColumnas[j] += arreglo[i][j];
        }
    }
}

void imprimirArreglo(int arreglo[FILAS][COLUMNAS]) {
    for (int i = 0; i < FILAS; i++) {
        for (int j = 0; j < COLUMNAS; j++) {
            std::cout << arreglo[i][j] << "\t";
        }
        std::cout << std::endl;
    }
}

void imprimirSumatorias(int sumatoriasFilas[FILAS], int sumatoriasColumnas[COLUMNAS]) {
    std::cout << "Sumatorias por renglones: ";
    for (int i = 0; i < FILAS; i++) {
        std::cout << sumatoriasFilas[i] << " ";
    }
    std::cout << std::endl;

    std::cout << "Sumatorias por columnas: ";
    for (int j = 0; j < COLUMNAS; j++) {
        std::cout << sumatoriasColumnas[j] << " ";
    }
    std::cout << std::endl;
}

int main() {
    int arreglo[FILAS][COLUMNAS];
    int sumatoriasFilas[FILAS] = {0};
    int sumatoriasColumnas[COLUMNAS] = {0};

    leerArreglo(arreglo);
    calcularSumatorias(arreglo, sumatoriasFilas, sumatoriasColumnas);
    std::cout << std::endl;

    std::cout << "Arreglo:" << std::endl;
    imprimirArreglo(arreglo);
    std::cout << std::endl;

    std::cout << "Sumatorias:" << std::endl;
    imprimirSumatorias(sumatoriasFilas, sumatoriasColumnas);

    return 0;
}

