#include <iostream>
#include <string>
#include <vector>

using namespace std;

int main() {
  vector<string> nombres;
  vector<double> ventas;
  double suma_ventas = 0;
  double promedio_ventas = 0;
  double nivel_comision = 0;
  double comision = 0;

  int num_vendedores;
  cout << "Ingrese el numero de vendedores: ";
  cin >> num_vendedores;
  for (int i = 0; i < num_vendedores; i++) {
    string nombre;
    double venta;
    cout << "Ingrese el nombre del vendedor " << i+1 << ": ";
    cin >> nombre;
    cout << "Ingrese la venta del vendedor " << i+1 << ": ";
    cin >> venta;
    nombres.push_back(nombre);
    ventas.push_back(venta);
    suma_ventas += venta;
  }

  promedio_ventas = suma_ventas / num_vendedores;
  nivel_comision = 0.75 * promedio_ventas;

  cout << "\nReporte de comisiones de ventas:" << endl;
  for (int i = 0; i < num_vendedores; i++) {
    if (ventas[i] > nivel_comision) {
      comision = 0.05 * (ventas[i] - nivel_comision);
      cout << "Vendedor: " << nombres[i] << endl;
      cout << "Venta: " << ventas[i] << endl;
      cout << "Comision: " << comision << endl << endl;
    }
  }

  return 0;
}
