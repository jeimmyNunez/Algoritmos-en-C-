#include <iostream>
#include <string>

using namespace std;

int main() {
    string nombres[15];

    // Leer nombres
    for (int i = 0; i < 15; i++) {
        cout << "Ingrese el nombre " << i+1 << ": ";
        cin >> nombres[i];
    }

    // Ordenar nombres en orden descendente usando el algoritmo de selección
    for (int i = 0; i < 14; i++) {
        int max_index = i;
        for (int j = i+1; j < 15; j++) {
            if (nombres[j] > nombres[max_index]) {
                max_index = j;
            }
        }
        if (max_index != i) {
            string temp = nombres[i];
            nombres[i] = nombres[max_index];
            nombres[max_index] = temp;
        }
    }

    // Imprimir nombres en orden descendente
    cout << "\nLos nombres en orden descendente son:\n";
    for (int i = 0; i < 15; i++) {
        cout << nombres[i] << endl;
    }

    return 0;
}
