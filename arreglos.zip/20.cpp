/*Elaborar un algoritmo que permita leer n�meros en una matriz de 5 x 6. Debe
imprimir dicha matriz y la sumatoria por renglones y por columnas utilizando un
arreglo unidimensional para obtener la sumatoria de todos los renglones y otro
arreglo de una dimensi�n para calcular la sumatoria de todas las columnas.*/

#include<iostream>
#include<conio.h>
#include<string>

using namespace std;

int main(){
	int matriz[4][5];
	int r, c, renMay=0, colMay=0, sumaRen, sumaCol, mayorRen, mayorCol;
	cout << "-----------------------------LECTURA DE DATOS--------------------- "  << endl;
	for (r = 0; r <= 3; r++){
		for (c = 0; c <= 4; c++){
		    cout << "Teclee matriz[" << r << "," << c << "]: ";
            cin >> matriz[r][c];	
		}
	}
	mayorRen = -9999;
    for (r = 0; r <= 3; r++){
    	sumaRen = 0;
        for (c = 0; c <= 4; c++){
        	cout << matriz[r][c] << "  ";
            sumaRen = sumaRen + matriz[r][c];
        }
        cout << "suma " << sumaRen <<endl;
        
    }
    for (c = 0; c <= 4; c++){
    	sumaCol = 0;
        for (r = 0; r <= 3; r++){
        	cout << matriz[r][c] << "  ";
            sumaCol = sumaCol + matriz[r][c];
        }
        cout << "suma " << sumaCol <<endl;
        
    }
       
}
