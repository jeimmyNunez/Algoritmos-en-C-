#include <iostream>
using namespace std;

int main() {
  int A[3][4];
  cout << "Ingrese los elementos de la matriz A:" << endl;
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 4; j++) {
      cout << "A[" << i << "][" << j << "]: ";
      cin >> A[i][j];
    }
  }

  int B[4][5];
  cout << "Ingrese los elementos de la matriz B:" << endl;
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 5; j++) {
      cout << "B[" << i << "][" << j << "]: ";
      cin >> B[i][j];
    }
  }

  int P[3][5] = {0};
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 5; j++) {
      for (int k = 0; k < 4; k++) {
        P[i][j] += A[i][k] * B[k][j];
      }
    }
  }

  cout << "La matriz resultante es:" << endl;
  for (int i = 0; i < 3; i++) {
    for (int j = 0; j < 5; j++) {
      cout << P[i][j] << " ";
    }
    cout << endl;
  }

  return 0;
}
