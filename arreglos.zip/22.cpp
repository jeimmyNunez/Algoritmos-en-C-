#include <iostream>
using namespace std;

int main() {
  int A[6][4];
  cout << "Ingrese los elementos de la matriz A:" << endl;
  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 4; j++) {
      cout << "A[" << i << "][" << j << "]: ";
      cin >> A[i][j];
    }
  }

  int B[6][4];
  cout << "Ingrese los elementos de la matriz B:" << endl;
  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 4; j++) {
      cout << "B[" << i << "][" << j << "]: ";
      cin >> B[i][j];
    }
  }

  cout << "La matriz A es:" << endl;
  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 4; j++) {
      cout << A[i][j] << " ";
    }
    cout << endl;
  }
  cout << "La matriz B es:" << endl;
  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 4; j++) {
      cout << B[i][j] << " ";
    }
    cout << endl;
  }

  bool a_mayor_que_b = false;
  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 4; j++) {
      if (A[i][j] < B[i][j]) {
        a_mayor_que_b = false;
        break;
      } else if (A[i][j] > B[i][j]) {
        a_mayor_que_b = true;
      }
    }
    if (a_mayor_que_b) {
      break;
    }
  }

  if (a_mayor_que_b) {
    cout << "La matriz A es mayor que la matriz B." << endl;
  } else {
    cout << "La matriz A no es mayor que la matriz B." << endl;
  }

  return 0;
}
