#include <iostream>

using namespace std;

const int SUCURSALES = 8;
const int DEPARTAMENTOS = 6;
const int VENDEDORES = 4;
const int DIAS = 7;

int main() {
    
    int ventas[SUCURSALES][DEPARTAMENTOS][VENDEDORES][DIAS] = {0};
    
    
    for (int s = 0; s < SUCURSALES; s++) {
        for (int d = 0; d < DEPARTAMENTOS; d++) {
            for (int v = 0; v < VENDEDORES; v++) {
                for (int dia = 0; dia < DIAS; dia++) {
                    cout << "Ingrese las ventas de la sucursal " << s+1
                         << ", departamento " << d+1 << ", vendedor " << v+1
                         << ", día " << dia+1 << ": ";
                    cin >> ventas[s][d][v][dia];
                }
            }
        }
    }
    
    
    cout << "REPORTE SEMANAL DE VENTAS\n";
    for (int s = 0; s < SUCURSALES; s++) {
        cout << "─────────────────────── SUCURSAL " << s+1 << " ───────────────────────\n";
        cout << " DÍA 1 DÍA 2 DÍA 3 DÍA 4 DÍA 5 DÍA 6 DÍA 7\n";
        cout << "──── ──── ──── ──── ──── ──── ────\n";
        for (int d = 0; d < DEPARTAMENTOS; d++) {
            cout << "DEPARTAMENTO-" << d+1 << " ";
            for (int dia = 0; dia < DIAS; dia++) {
                int ventas_departamento = 0;
                for (int v = 0; v < VENDEDORES; v++) {
                    ventas_departamento += ventas[s][d][v][dia];
                }
                cout << ventas_departamento << " ";
            }
            cout << endl;
        }
    }
    
    return 0;
}