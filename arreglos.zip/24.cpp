#include <iostream>
#include <string>

using namespace std;

const int NUM_PLANTAS = 12;
const int NUM_DIAS = 7;

int main()
{
    // Declaración de variables
    string nombres[NUM_PLANTAS];
    int produccion[NUM_PLANTAS][NUM_DIAS];
    int totalProduccion[NUM_DIAS] = {0};
    int plantaMasProductiva = 0;
    int produccionMasAlta = 0;
    int diaMasProductivo = 0;
    int produccionDiaMasAlto = 0;

    // Lectura de los nombres de las plantas y su producción
    for(int i = 0; i < NUM_PLANTAS; i++)
    {
        cout << "Introduzca el nombre de la planta " << i+1 << ": ";
        cin >> nombres[i];

        cout << "Introduzca la producción de la planta " << nombres[i] << " para cada día de la semana:" << endl;

        for(int j = 0; j < NUM_DIAS; j++)
        {
            cout << "Día " << j+1 << ": ";
            cin >> produccion[i][j];

            totalProduccion[j] += produccion[i][j];

            if(produccion[i][j] > produccionMasAlta)
            {
                produccionMasAlta = produccion[i][j];
                plantaMasProductiva = i;
                diaMasProductivo = j;
            }
        }
    }

    // Impresión del reporte semanal de producción
    cout << endl << "REPORTE SEMANAL DE PRODUCCCIÓN" << endl << endl;
    cout << "PLANTA\tDÍA 1\tDÍA 2\tDÍA 3\tDÍA 4\tDÍA 5\tDÍA 6\tDÍA 7\tPROD. SEMANAL" << endl;

    for(int i = 0; i < NUM_PLANTAS; i++)
    {
        cout << nombres[i] << "\t";
        int total = 0;

        for(int j = 0; j < NUM_DIAS; j++)
        {
            cout << produccion[i][j] << "\t";
            total += produccion[i][j];
        }

        cout << total << endl;
    }

    cout << "TOTALES\t";

    for(int i = 0; i < NUM_DIAS; i++)
    {
        cout << totalProduccion[i] << "\t";
    }

    cout << endl << endl;
    cout << "PLANTA MÁS PRODUCTIVA: " << nombres[plantaMasProductiva] << endl;
    cout << "PRODUCCIÓN DE LA PLANTA MÁS PRODUCTIVA: " << produccionMasAlta << endl;
    cout << "DÍA CON MAYOR PRODUCCIÓN: " << diaMasProductivo+1 << endl;

    int produccionTotalMasAlta = 0;

    for(int i = 0; i < NUM_PLANTAS; i++)
    {
        if(produccion[i][diaMasProductivo] > produccionDiaMasAlto)
        {
            produccionDiaMasAlto = produccion[i][diaMasProductivo];
            produccionTotalMasAlta = 0;
        }

    cout << "PRODUCCIÓN TOTAL EN EL DÍA MÁS PRODUCTIVO: " << produccionTotalMasAlta << endl;
    return 0;
}

