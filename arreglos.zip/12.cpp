#include <iostream>
#include <string>

using namespace std;

const int NUM_ESTACIONES = 15;
const int NUM_MESES = 12;

int main() {
    string nombres[NUM_ESTACIONES];
    int produccion[NUM_ESTACIONES][NUM_MESES];

    // Leer nombres y producción por mes de cada estación
    for (int i = 0; i < NUM_ESTACIONES; i++) {
        cout << "Ingrese el nombre del encargado de la estación " << i+1 << ": ";
        cin >> nombres[i];
        for (int j = 0; j < NUM_MESES; j++) {
            cout << "Ingrese la producción para el mes " << j+1 << " de la estación " << i+1 << ": ";
            cin >> produccion[i][j];
        }
    }

    // Calcular la producción total de cada estación
    int produccion_total[NUM_ESTACIONES];
    for (int i = 0; i < NUM_ESTACIONES; i++) {
        produccion_total[i] = 0;
        for (int j = 0; j < NUM_MESES; j++) {
            produccion_total[i] += produccion[i][j];
        }
    }

    // Calcular la producción total de todas las estaciones
    int produccion_total_general = 0;
    for (int i = 0; i < NUM_ESTACIONES; i++) {
        produccion_total_general += produccion_total[i];
    }

    // Encontrar la estación más productiva
    int estacion_mas_productiva = 0;
    for (int i = 1; i < NUM_ESTACIONES; i++) {
        if (produccion_total[i] > produccion_total[estacion_mas_productiva]) {
            estacion_mas_productiva = i;
        }
    }

    // Imprimir el informe de análisis de producción
    cout << "ANÁLISIS DE PRODUCCIÓN\n";
    cout << "ESTACIÓN TOTAL PRODUCCIÓN\n";
    cout << "────────────────────────────\n";
    for (int i = 0; i < NUM_ESTACIONES; i++) {
        cout << " " << i+1 << " ";
        cout << produccion_total[i] << endl;
    }
    cout << " TOTAL " << produccion_total_general << endl;
    cout << "ESTACIÓN MÁS PRODUCTIVA: " << estacion_mas_productiva+1 << endl;
    cout << "ENCARGADO DE LA ESTACIÓN: " << nombres[estacion_mas_productiva] << endl;
    cout << "CANTIDAD PRODUCIDA: " << produccion_total[estacion_mas_productiva] << endl;

    return 0;
}
