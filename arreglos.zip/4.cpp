#include <iostream>
#include <cmath>

using namespace std;

int main() {
    const int tam = 15;
    int arr[tam];
    double sum = 0, media, desviacion, arriba = 0, abajo = 0, igual = 0;

    for (int i = 0; i < tam; i++) {
        cout << "Ingrese un numero: " << i+1 << ": ";
        cin >> arr[i];
        sum += arr[i];
    }

    media = sum / tam;


    cout << "ELEMENTO\tDESVIACION" << endl;
    for (int i = 0; i < media; i++) {
        desviacion= arr[i] - media;
        cout << arr[i] << "\t" << desviacion << endl;
        if (desviacion > 0) {
            arriba++;
        } else if (desviacion < 0) {
            abajo++;
        } else {
            igual++;
        }
    }
    
    cout << "---------------------------------------------------------------------"  << endl;
    cout << "MEDIA = " << media << endl;
    cout << "---------------------------------------------------------------------"  << endl;
    cout << "TOTAL DE ELEMENTOS ARRIBA DE LA MEDIA: " << arriba << endl;
    cout << "---------------------------------------------------------------------"  << endl;
    cout << "TOTAL DE ELEMENTOS ABAJO DE LA MEDIA: " << abajo << endl;
    cout << "---------------------------------------------------------------------"  << endl;
    cout << "TOTAL DE ELEMENTOS IGUAL A LA MEDIA: " << igual << endl;
    cout << "---------------------------------------------------------------------"  << endl;

    return 0;
}
