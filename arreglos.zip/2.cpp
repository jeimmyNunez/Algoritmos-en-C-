#include <iostream>
using namespace std;

int main() {
  int ventas[30]; 
  int max = 0, min = 0;
  int posMax = 0, posMin = 0; 

  for(int i = 0; i < 30; i++) {
    cout << "Ingresa la venta para el dia " << i+1 << ": ";
    cin >> ventas[i];
 
    if (ventas[i] > ventas[max]) {
      max = i;
      posMax = max;
    }

    if (ventas[i] < ventas[min]) {
      min = i;
      posMin = min;
    }
  }
  
  cout << "---------------------------------------------------------------------"  << endl;
  cout << "El dia con mayor venta fue, el: " << posMax+1 << " con una venta de $" << ventas[posMax] << endl;
  cout << "---------------------------------------------------------------------"  << endl;
  cout << "El dia con menor venta fue, el: " << posMin+1 << " con una venta de $" << ventas[posMin] << endl;
  cout << "---------------------------------------------------------------------"  << endl;
  
  return 0;
}


