#include <iostream>
#include <iomanip> 
using namespace std;

const int SUCURSALES = 8;
const int DEPARTAMENTOS = 6;
const int VENDEDORES = 4;
const int DIAS_SEMANA = 7;

int main() {
	
    double ventas[SUCURSALES][DEPARTAMENTOS][VENDEDORES][DIAS_SEMANA] = {0.0};

    for (int i = 0; i < SUCURSALES; i++) {
        for (int j = 0; j < DEPARTAMENTOS; j++) {
            for (int k = 0; k < VENDEDORES; k++) {
                cout << "Ingrese las ventas de la sucursal " << i+1
                     << ", departamento " << j+1 << ", vendedor " << k+1 << ": ";
                for (int l = 0; l < DIAS_SEMANA; l++) {
                    cin >> ventas[i][j][k][l];
                }
            }
        }
    }

    cout << "\nVentas totales por sucursal:" << endl;
    for (int i = 0; i < SUCURSALES; i++) {
        double total = 0.0;
        for (int j = 0; j < DEPARTAMENTOS; j++) {
            for (int k = 0; k < VENDEDORES; k++) {
                for (int l = 0; l < DIAS_SEMANA; l++) {
                    total += ventas[i][j][k][l];
                }
            }
        }
        cout << "Sucursal " << i+1 << ": $" << setw(10) << total << endl;
    }

    cout << "\nVentas totales por departamento:" << endl;
    for (int j = 0; j < DEPARTAMENTOS; j++) {
        double total = 0.0;
        for (int i = 0; i < SUCURSALES; i++) {
            for (int k = 0; k < VENDEDORES; k++) {
                for (int l = 0; l < DIAS_SEMANA; l++) {
                    total += ventas[i][j][k][l];
                }
            }
        }
        cout << "Departamento " << j+1 << ": $" << setw(10) << total << endl;
    }


  cout << "\nVentas totales por vendedor:" << endl;
    for (int k = 0; k < VENDEDORES; k++) {
        double total = 0.0;
        for (int i = 0; i < SUCURSALES; i++) {
            for (int j = 0; j < DEPARTAMENTOS; j++) {
                for (int l = 0; l < DIAS_SEMANA; l++) {
                    total += ventas[i][j][k][l];
                }
            }
        }
        cout << "Vendedor " << k+1 << ": $" << setw(10) << total << endl;
    }


    double total = 0.0;
    for (int i = 0; i < SUCURSALES; i++) {
        for (int j = 0; j < DEPARTAMENTOS; j++) {
            for (int k = 0; k < VENDEDORES; k++) {
                for (int l = 0; l < DIAS_SEMANA; l++) {
                    total += ventas[i][j][k][l];
                }
            }
        }
    }
    cout << "\nVenta total de la compa�ia: $" << setw(10) << total << endl;

    return 0;
}
