/*Se tiene la producci�n de los 7 d�as de la semana de 20 plantas. Elaborar un
algoritmo que lea estos datos y los almacene en un arreglo de 20 renglones
para las plantas, en 7 columnas para cada d�a de producci�n, y que imprima el
n�mero de planta que tuvo la mayor producci�n semanal.*/

#include<iostream>
#include<conio.h>
#include<string>

using namespace std;

int main(){
	
	int prod[6][4][5];
    int pla, est, dia, totEst, totDia, totPlanta, totProd,mayPla, mayProdPla, mayEst=0, mayProdEst=0;
     cout << "-----------------------------LECTURA DE DATOS--------------------- "  << endl;
    for (pla = 0; pla <= 5; pla++){
    	for (est = 0; est <= 3; est++){
    		cout << "  Planta " << (pla+1) << "  ";
    		cout << "Estacion " << (est+1) <<endl;
    		for (dia = 0; dia <= 4; dia++){
    			cout << "Produccion dia " << (dia+1) << ": ";
    			cin >> prod[pla][est][dia];
    		}
    	}
    }
    cout << "-----------------------------REPORTE SEMANAL DE PRODUCCION--------------------- "  << endl;
    totProd = 0;
    mayProdPla = 0;
    for (pla = 0; pla <= 5; pla++){
    	cout << "\n------------------- Planta " << (pla+1) << " ------------------" <<endl;
    	cout << "Dia 1 Dia 2 Dia 3 Dia 4 Dia 5 TOTAL" << endl;
        cout << " ----- ----- ----- ----- ----- -----" <<endl;
		mayProdEst = 0;
        for (est = 0; est <= 3; est++){
            cout << "Estacion-" << (est+1) << "     ";
            totEst = 0;
        for (dia = 0; dia <= 4; dia++){
           cout << prod[pla][est][dia] << "     ";
           totEst += prod[pla][est][dia];	
        }
        cout << totEst <<endl;
         if (totEst > mayProdEst){
         	mayProdEst = totEst;
            mayEst = est + 1;
         }
        }
		cout << "-----------------------------TOTALES--------------------- "  << endl;	
		totPlanta = 0;
        for (dia = 0; dia <= 4; dia++){
        	totDia = 0;
            for (est = 0; est <= 3; est++){
                 totDia = totDia + prod[pla][est][dia];	
			}
			cout << totDia << "    ";
			totPlanta = totPlanta + totDia; 
        }
        cout << totPlanta <<endl;
        cout << " planta mas productiva : " << mayEst << endl;
        cout << "Produccion  mas productiva : " << mayProdEst << endl;
         if (totPlanta > mayProdPla)
           { 
              mayProdPla = totPlanta;
              mayPla = pla + 1; 
           }
           totProd = totProd + totPlanta;
           
    }
    cout << " Total general de produccion =     " << totProd << endl;
    std::cout << "\n Planta mas productiva = " << mayEst << endl;
    std::cout << "Produccion de planta mas productiva = " << mayProdEst <<endl;
    return 0;
}

