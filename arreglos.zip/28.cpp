#include <iostream>
using namespace std;

const int SUCURSALES = 8;
const int DEPARTAMENTOS = 6;
const int DIAS_SEMANA = 7;

int main() {
    int ventas[SUCURSALES][DEPARTAMENTOS][DIAS_SEMANA];

    
    for (int i = 0; i < SUCURSALES; i++) {
        for (int j = 0; j < DEPARTAMENTOS; j++) {
            cout << "Ingrese las ventas de la sucursal " << i+1 << ", departamento " << j+1 << endl;
            for (int k = 0; k < DIAS_SEMANA; k++) {
                cout << "Dia " << k+1 << ": ";
                cin >> ventas[i][j][k];
            }
        }
    }

    
    cout << "REPORTE SEMANAL DE VENTAS" << endl;
    for (int i = 0; i < SUCURSALES; i++) {
        cout << "─────────────────────── SUCURSAL " << i+1 << " ───────────────────────" << endl;
        cout << " DÍA 1 DÍA 2 DÍA 3 DÍA 4 DÍA 5 DÍA 6 DÍA 7" << endl;
        cout << "──── ──── ──── ──── ──── ──── ────" << endl;
        for (int j = 0; j < DEPARTAMENTOS; j++) {
            cout << "DEPARTAMENTO-" << j+1 << " ";
            for (int k = 0; k < DIAS_SEMANA; k++) {
                cout << ventas[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }

    return 0;
}