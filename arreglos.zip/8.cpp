/*Elaborar un algoritmo que permita leer 25 n�meros en un arreglo e imprima el arreglo y la cantidad de n�meros que son cero, la cantidad de n�meros que
est�n abajo de cero y la cantidad de n�meros arriba de cero.*/
#include<iostream>
#include<conio.h>
#include<string>

using namespace std;

   const int numeros =25;
   
int main(){
	
	float valores[numeros],sonCero=0,menores=0,mayores=0;
	int mayor=0;
	
	for(float i=0;i<=24;i++){
		cout<<"digite los numeros : ";
		cin>>valores[numeros];
		 if (valores[numeros] == 0)
         sonCero++;
        else if (valores[numeros] < 0)
         menores++;
        else
         mayores++;
	}
      
    
  cout << endl << "Numeros iguales a cero " << sonCero << endl;
  cout << "Numeros menores que cero " << menores << endl;
  cout << "Numeros mayores que cero " << mayores << endl;
  
	
	getch();
	return 0;
	
}
