#include <iostream>
#include <string>
using namespace std;

int main(){
	   string nombreObr, obrMayor="", obrMenor="", entradaChar;
       int    proDia, totProd, toTotProd, totObreros, i, mayorProd, menorProd;
       float  sueldo=0, totSueldos; 
       char   otro;
      cout<<"\n"<<"******************************REPORTE DE PRODUCCION****************************************"<<"\n"<<endl;
       totObreros = 0;
       toTotProd = 0;
       totSueldos = 0;
       mayorProd = 0;
       menorProd = 10000;
       for (i=1; i<=15; i++){
       	cout<<"Ingrese nombre : ";
		cin>>nombreObr;
		totProd = 0;
		do{
		cout<<"Ingrese produccion del dia : ";
		 cin>>proDia;
		 totProd = totProd + proDia;
		 cout<<"�desea procesar otro dia s/n?: "<<endl;
         cin>>otro;	
		}while(otro!='n');
		if(totProd <= 500 )
			sueldo = totProd * 20.00F;
		
		if (totProd > 500 && totProd <= 800)
			sueldo = totProd * 25.00F;
		
		if(totProd > 800 )
		sueldo = totProd * 30.00F;	
		
		
		cout<<"\n"<<"--------------------Lectura de datos-------------------"<<"\n"<<endl;
		cout<<"\n"<<"NOMBRE"<<"\t"<<"TOTAL PRODUCCION"<<"\t"<<"SUELDO"<<"\n"<<endl;
		cout<<"\n"<<nombreObr<<"\t\t"<<totProd<<"\t\t"<<sueldo<<endl;	
		 if (totProd > mayorProd)
           {
              mayorProd = totProd;
              obrMayor = nombreObr;
           }

           if (totProd < menorProd)
           {
              menorProd = totProd;
              obrMenor = nombreObr;
           }
           totObreros = totObreros + 1;
           toTotProd = toTotProd + totProd;
           totSueldos = totSueldos + sueldo;
		}
		cout<<"\n"<<"******************************TOTALES****************************************"<<"\n"<<endl;
       cout<<"TOTAL OBREROS: "<<totObreros<<endl;
       cout<<"TOTAL PRODUCCION: "<<toTotProd<<endl;
       cout<<"TOTAL SUELDOS: "<<totSueldos<<endl;
       cout<<"OBRERO MAYOR: "<<obrMayor<<endl;
       cout<<"MAYOR PRODUCCION : "<<mayorProd<<endl;
       cout<<"OBRERO MENOR: "<<obrMenor<<endl;
       cout<<"MENOR PRODUCCION: "<<menorProd<<endl;
		   

}
