#include <iostream>
#include <vector>
using namespace std;

struct Estacion {
    int produccion[7]; 
    int total_produccion; 
    string comentario; 
};

int main() {
    const int ESTACIONES = 10; 
    vector<Estacion> estaciones(ESTACIONES);
    int nivel_productividad; 
    int contador_deficiente = 0, contador_bueno = 0, contador_excelente = 0; 
    float porcentaje_deficiente, porcentaje_bueno, porcentaje_excelente; 

    cout << "Ingrese el nivel de productividad: ";
    cin >> nivel_productividad;

    for (int i = 0; i < ESTACIONES; i++) {
        cout << "Estacion " << i+1 << ":" << endl;
        estaciones[i].total_produccion = 0;
        for (int j = 0; j < 7; j++) {
            cout << "Produccion del dia " << j+1 << ": ";
            cin >> estaciones[i].produccion[j];
            estaciones[i].total_produccion += estaciones[i].produccion[j];
        }
        if (estaciones[i].total_produccion < nivel_productividad) {
            estaciones[i].comentario = "DEFICIENTE";
            contador_deficiente++;
        } else if (estaciones[i].total_produccion == nivel_productividad) {
            estaciones[i].comentario = "BUENO";
            contador_bueno++;
        } else {
            estaciones[i].comentario = "EXCELENTE";
            contador_excelente++;
        }
    }
    cout << "Reporte de produccion por estacion:" << endl;
    cout << "Estacion   Total produccion   Nivel de productividad" << endl;
    for (int i = 0; i < ESTACIONES; i++) {
        cout << "   " << i+1 << "             " << estaciones[i].total_produccion
             << "                  " << estaciones[i].comentario << endl;
    }

    porcentaje_deficiente = (float)contador_deficiente / ESTACIONES * 100;
    porcentaje_bueno = (float)contador_bueno / ESTACIONES * 100;
    porcentaje_excelente = (float)contador_excelente / ESTACIONES * 100;

    cout << "Porcentaje de estaciones con nivel de productividad DEFICIENTE: "
         << porcentaje_deficiente << "%" << endl;
    cout << "Porcentaje de estaciones con nivel de productividad BUENO: "
         << porcentaje_bueno << "%" << endl;
    cout << "Porcentaje de estaciones con nivel de productividad EXCELENTE: "
         << porcentaje_excelente << "%" << endl;

    return 0;
}
