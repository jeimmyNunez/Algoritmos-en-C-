#include <iostream>
#include <string>
 using namespace std;

 //ciclo for (inicializacion ; condicion ;  aumento o decremento){}

 int main () {

 int sumas, sumas2, sumas3;
 int i;
char costproductoA;
     int costomaterial1;
     int  costomaterial2;
    int costomaterial3;
    int  costomaterial4;
     int  costomaterial5;
     int costomaterial6;



char costproductoB;
     int Costmaterial1;
     int Costmaterial2;
     int Costmaterial3;
     int Costmaterial4;
     int Costmaterial5;
     int Costmaterial6;


char costproductoc;
     int costmaterial_1;
     int costmaterial_2;
     int costmaterial_3;
     int costmaterial_4;
     int costmaterial_5;
     int costmaterial_6;




        cout << "Ingrese el costo estimado del  material 1:" << endl;
            cin>>costomaterial1;
        cout << "Ingrese el costo estimado del material 2:" << endl;
           cin>>costomaterial2;
        cout << "Ingrese el costo estimado del material 3:" << endl;
       cin>>costomaterial3;
        cout << "Ingrese el costo estimado del material 4:" << endl;
        cin>>costomaterial4;
        cout << "Ingrese el costo estimado del material 5:" << endl;
      cin>>costomaterial5;
        cout << "Ingrese el costo estimado del material 6:" << endl;
        cin>>costomaterial6;
           

cout <<"PRODUCTO B" << endl;

        cout << "Ingrese el costo estimado del  material 1:" << endl;
            cin>>Costmaterial1;
        cout << "Ingrese el costo estimado del material 2:" << endl;
            cin>>Costmaterial2;
        cout << "Ingrese el costo estimado del material 3:" << endl;
        cin>>Costmaterial3;
        cout << "Ingrese el costo estimado del material 4:" << endl;
        cin>>Costmaterial4;
        cout << "Ingrese el costo estimado del material 5:" << endl;
        cin>>Costmaterial5;
        cout << "Ingrese el costo estimado del material 6:" << endl;
        cin>>Costmaterial6;

cout <<"PRODUCTO C" << endl;

        cout << "Ingrese el costo estimado del  material 1:" << endl;
            cin>>costmaterial_1;
        cout << "Ingrese el costo estimado del material 2:" << endl;
            cin>>costmaterial_2;
        cout << "Ingrese el costo estimado del material 3:" << endl;
        cin>>costmaterial_3;
        cout << "Ingrese el costo estimado del material 4:" << endl;
        cin>>costmaterial_4;
        cout << "Ingrese el costo estimado del material 5:" << endl;
        cin>>costmaterial_5;
        cout << "Ingrese el costo estimado del material 6:" << endl;
        cin>>costmaterial_6;

cout <<"¿desea ver las tablas?" << endl;
cin>>i;
 system("color f9");
    
for(i=1; i<=1; i++){

    
     cout <<"                              " << left <<"LISTADO DE MATERIALES REQUERIDOS." << endl;
        cout <<"PRODUCTO A." << endl;
        cout <<"MATERIAL.                TOTAL DE UNIDADES.        COSTO ESTIMADO. " <<endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 1 <<"                           "<< left << "3_unidades" <<"                    "<< costomaterial1 <<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout <<2 <<"                           "<< left << "4_unidades" <<"                     "<< costomaterial2 <<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout <<3<<"                             "<< left << "1_unidad" <<"                    "<< costomaterial3 <<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout <<4 <<"                           "<< left << "2_unidades" <<"                     "<< costomaterial4 <<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 5 <<"                          "<< left << "3_unidades" <<"                     "<< costomaterial5 <<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 6 <<"                        "<< left << "2_unidades"<<"                       "<< costomaterial6 <<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
            
            sumas = costomaterial1 + costomaterial2 + costomaterial3 + costomaterial4 + costomaterial5 + costomaterial6;
            
        cout <<"COSTO TOTAL:" << left << sumas << endl;

      cout <<"                              " << left <<"LISTADO DE MATERIALES REQUERIDOS." << endl;
        cout <<"PRODUCTO B." << endl;
        cout <<"MATERIAL.                TOTAL DE UNIDADES.        COSTO ESTIMADO. " <<endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 1 <<"                           "<< left << "2_unidades"<<"                    "<< Costmaterial1<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout <<2 <<"                           "<< left << "5_unidades" <<"                     "<< Costmaterial2<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout <<3<<"                             "<< left << "2_unidades" <<"                    "<< Costmaterial3<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout <<4 <<"                           "<< left << "1_unidad" <<"                     "<< Costmaterial4<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 5 <<"                          "<< left << "2_unidades" <<"                     "<< Costmaterial5<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 6 <<"                        "<< left << "4_unidades"  <<"                       "<< Costmaterial6<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
 
            sumas2 = Costmaterial1 + Costmaterial2 + Costmaterial3 + Costmaterial4 + Costmaterial5 + Costmaterial6;
    
        cout <<"COSTO TOTAL:" << left << sumas2 << endl;


  cout <<"                              " << left <<"LISTADO DE MATERIALES REQUERIDOS." << endl;
        cout <<"PRODUCTO A." << endl;
        cout <<"MATERIAL.                TOTAL DE UNIDADES.        COSTO ESTIMADO. " <<endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 1 <<"                           "<< left << "7_unidades" <<"                   "<< costmaterial_1<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 2 <<"                           "<< left << "1_unidad" <<"                   "<< costmaterial_2<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 3 <<"                             "<< left << "5_unidades" <<"                 "<< costmaterial_3<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 4 <<"                           "<< left << "4_unidades" <<"                   "<< costmaterial_4<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 5 <<"                          "<< left << "2_unidades" <<"                    "<< costmaterial_5<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;
        cout << 6 <<"                        "<< left << "3_unidades" <<"                      "<< costmaterial_6<<"         " << endl;
        cout << "-----------------------------------------------------------------------------" << endl;

   
            sumas3 = costmaterial_1 + costmaterial_2 + costmaterial_3 + costmaterial_4 + costmaterial_5 + costmaterial_6;
        
            cout <<"COSTO TOTAL:" << left << sumas3 << endl;
            }

return 0;

 }