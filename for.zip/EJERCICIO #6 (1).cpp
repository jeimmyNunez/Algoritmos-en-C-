#include <iostream>
#include <string>

using namespace std;

const int NUM_JUGA = 12;
const int NUM_PARTI = 10;


double calcularPromedio(int puntos[]) {
    double total = 0;
    for (int i = 0; i < NUM_PARTI; i++) {
        total += puntos[i];
    }
    return total / NUM_PARTI;
}


string determinarNivel(double promedio) {
    if (promedio < 10) {
        return "DEFICIENTE";
    } else if (promedio < 15) {
        return "REGULAR";
    } else if (promedio < 20) {
        return "BUENO";
    } else {
        return "EXCELENTE";
    }
}

int main() {
    string nombres[NUM_JUGA];
    int puntos[NUM_JUGA][NUM_PARTI];

   
    for (int i = 0; i < NUM_JUGA; i++) {
        cout << "Ingrese el nombre del jugador " << i+1 << ": ";
        cin >> nombres[i];
        for (int j = 0; j < NUM_PARTI; j++) {
            cout << "Ingrese los puntos anotados en el partido " << j+1 << ": ";
            cin >> puntos[i][j];
        }
    }

  
    cout << "ESTADISTICA DE JUGADORES" << endl;
    cout << "NOMBRE\tTOTAL\tNIVEL DE ANOTACION" << endl;
    cout << "---------------------------------------" << endl;
    for (int i = 0; i < NUM_JUGA; i++) {
        double promedio = calcularPromedio(puntos[i]);
        string nivel = determinarNivel(promedio);
        cout << nombres[i] << "\t";
        cout << promedio << "\t";
        cout << nivel << endl;
    }

  
    int mejorIndex = 0, peorIndex = 0;
    double mejorPromedio = calcularPromedio(puntos[0]), peorPromedio = mejorPromedio;
    for (int i = 1; i < NUM_JUGA; i++) {
        double promedio = calcularPromedio(puntos[i]);
        if (promedio > mejorPromedio) {
            mejorPromedio = promedio;
            mejorIndex = i;
        }
        if (promedio < peorPromedio) {
            peorPromedio = promedio;
            peorIndex = i;
        }
    }

    // Imprimir los resultados finales
    cout << "---------------------------------------" << endl;
    cout << "TOTAL " << NUM_JUGA << " JUGADORES\t\t" << endl;
    cout << "NOMBRE DEL MEJOR ANOTADOR: " << nombres[mejorIndex] << endl;
    cout << "NOMBRE DEL PEOR ANOTADOR: " << nombres[peorIndex] << endl;

    return 0;
}

