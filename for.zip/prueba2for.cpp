#include <iostream> 
#include <iomanip> 
#include <conio.h>

using namespace std;

int main()
{
 
    string poblacion, mayorPobla, menorPobla;
    char hay, otro;
    int totPobla, totPobNoLluvia;
    float lluvia, totLluvia, toTotLluvia, mayorLluvia, menorLluvia;
    
    cout << endl << "------------------------------------------------------";
    cout << endl << " PROCESA LAS LLUVIAS DE POBLACIONES\n";
    cout << endl << "------------------------------------------------------";
    
    cout << endl << "------------------------------------------------------";
    cout << endl << " \t\tREPORTE DE LLUVIAS";
    cout << endl << "------------------------------------------------------";
    cout << endl << setw(20) << "POBLACION" << setw(20) << "TOTAL LLUVIA";
    cout << endl << "------------------------------------------------------";
    totPobla = 0;
    totPobNoLluvia = 0;
    toTotLluvia = 0;
    mayorLluvia = 0;
    menorLluvia = 0;
    cout << endl << "Hay poblacion(S/N): ";
    cin >> hay;
    cin.ignore();
    for (int i = 0; i < 45; i++)
    {

        cout << endl << "-------------- Lectura de datos --------------";
        cout << endl << "Ingrese el nombre de la poblacion : ";
        getline(cin, poblacion);
        
        totLluvia = 0;
        cout << endl << "Hay lluvia(S/N): ";
        cin >> otro;
        cin.ignore();
        while (otro == 'S' || otro == 's')
        {
            cout << " cantidad de lluvia: ";
            cin >> lluvia;
            totLluvia = totLluvia + lluvia;
            cout << endl << "Hay otra lluvia(S/N): ";
            cin >> otro;
            cin.ignore();
        }
        
        system ("cls");
        
    cout << endl << "------------------------------------------------------";
    cout << endl << " PROCESA LAS LLUVIAS DE POBLACIONES";
    cout << endl << "------------------------------------------------------";
    
    cout << endl << "------------------------------------------------------";
    cout << endl << " \t\tREPORTE DE LLUVIAS";
    cout << endl << "------------------------------------------------------";
    cout << endl << setw(20) << "POBLACION" << setw(20) << "TOTAL LLUVIA";
    cout << endl << "------------------------------------------------------";
        
    
        cout << endl << "----------------- Resultados -----------------";
        cout << endl << setw(20) << poblacion << setw(20) << totLluvia;
        
        totPobla = totPobla + 1;
        toTotLluvia = toTotLluvia + totLluvia;
        if (totLluvia > mayorLluvia)
        {
            mayorLluvia = totLluvia;
            mayorPobla = poblacion;
        }
        if (totLluvia < menorLluvia)
        {
            menorLluvia = totLluvia;
            menorPobla = poblacion;
        }
        if (totLluvia == 0)
        {
            totPobNoLluvia = totPobNoLluvia + 1;
        }
    }
    cout << endl << "------------------ Total -----------------";
    cout << endl << "Total de poblaciones = " << totPobla;
    cout << endl << "Lluvia total = " << toTotLluvia;
    cout << endl << "Total de poblaciones donde no llovio = " << totPobNoLluvia;
    cout << endl << "La poblaci�n con mayor cantidad de lluvia fue " << mayorPobla << " con un total de " << mayorLluvia << ".";
    cout << endl << "La poblaci�n con menor cantidad de lluvia fue " << menorPobla << " con un total de " << menorLluvia << ".";
    
    getch();
    return 0;
}
